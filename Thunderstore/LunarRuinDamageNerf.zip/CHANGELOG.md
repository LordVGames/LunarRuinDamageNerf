## 1.1.0

- Added a setting to make lunar ruin's damage nerf only apply to skill damage to prevent the damage bonus double-dipping for proc damage.
- - Defaults have been tweaked since this is enabled by default and it drastically affects how much of an impact the damage increase has.
- Mod now uses MonoDetour for IL hooking

## 1.0.1

- Fixed for memory optimization update

## 1.0.0

- First release