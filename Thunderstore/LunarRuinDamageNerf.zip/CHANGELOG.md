## 1.0.1

- Fixed for memory optimization update

## 1.0.0

- First release